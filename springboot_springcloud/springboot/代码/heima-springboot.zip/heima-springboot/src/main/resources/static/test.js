function hello() {
    alert("hello spring boot!")
}